<footer>
   <div class="pull-right">
      2021 <a href="https://colorlib.com">test</a>
   </div>
   <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>public/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo base_url(); ?>public/build/js/custom.min.js"></script>
</body>
</html>